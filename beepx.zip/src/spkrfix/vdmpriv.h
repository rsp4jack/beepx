BOOL VDMhook_Init(void *LazyBeep, const char *pszSig, int cbSig);
